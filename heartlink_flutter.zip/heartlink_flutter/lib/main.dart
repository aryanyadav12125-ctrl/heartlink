import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ⚠️ APNA FIREBASE CONFIG YAHAN REPLACE KARO
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "YOUR_API_KEY",
      appId: "YOUR_APP_ID",
      messagingSenderId: "YOUR_SENDER_ID",
      projectId: "YOUR_PROJECT_ID",
      databaseURL: "YOUR_DATABASE_URL",
    ),
  );

  await AwesomeNotifications().initialize(null, [
    NotificationChannel(
      channelKey: 'draw_channel',
      channelName: 'Live Drawing',
      channelDescription: 'Partner ki drawing lock screen par',
      defaultColor: const Color(0xFFF0607A),
      importance: NotificationImportance.Max,
      locked: false,
    ),
    NotificationChannel(
      channelKey: 'chat_channel',
      channelName: 'Chat',
      channelDescription: 'Partner ke messages',
      defaultColor: const Color(0xFFF0607A),
      importance: NotificationImportance.High,
    ),
  ]);

  await AwesomeNotifications().requestPermissionToSendNotifications(
    permissions: [
      NotificationPermission.Alert,
      NotificationPermission.Sound,
      NotificationPermission.Badge,
      NotificationPermission.Vibration,
      NotificationPermission.FullScreenIntent,
      NotificationPermission.CriticalAlert,
    ],
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarColor: Colors.transparent),
  );

  runApp(const HeartLinkApp());
}

class HeartLinkApp extends StatelessWidget {
  const HeartLinkApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HeartLink 💕',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0C0610),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFF0607A),
          secondary: Color(0xFFE8C07A),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
