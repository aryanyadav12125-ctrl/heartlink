import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyDRkqtbH27Uk6blN_lEVugt931g8F67y5Y",
      appId: "1:350458505598:web:182060d6536e854303ab2f",
      messagingSenderId: "350458505598",
      projectId: "heartlink-9c8f7",
      databaseURL: "https://heartlink-9c8f7-default-rtdb.firebaseio.com",
      storageBucket: "heartlink-9c8f7.firebasestorage.app",
    ),
  );

  await AwesomeNotifications().initialize(null, [
    NotificationChannel(
      channelKey: 'draw_channel',
      channelName: 'Live Drawing',
      channelDescription: 'Partner ki drawing lock screen par',
      defaultColor: const Color(0xFFF0607A),
      importance: NotificationImportance.Max,
      locked: false,
    ),
    NotificationChannel(
      channelKey: 'chat_channel',
      channelName: 'Chat',
      channelDescription: 'Partner ke messages',
      defaultColor: const Color(0xFFF0607A),
      importance: NotificationImportance.High,
    ),
  ]);

  await AwesomeNotifications().requestPermissionToSendNotifications(
    permissions: [
      NotificationPermission.Alert,
      NotificationPermission.Sound,
      NotificationPermission.Badge,
      NotificationPermission.Vibration,
      NotificationPermission.FullScreenIntent,
      NotificationPermission.CriticalAlert,
    ],
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarColor: Colors.transparent),
  );

  runApp(const HeartLinkApp());
}

class HeartLinkApp extends StatelessWidget {
  const HeartLinkApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HeartLink 💕',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0C0610),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFF0607A),
          secondary: Color(0xFFE8C07A),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
