import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import '../services/fb.dart';
import 'auth_screen.dart';
import 'home_screen.dart';
import 'connect_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _State();
}

class _State extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ac;
  late Animation<double> _scale, _fade;
  int _taps = 0;

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _scale = Tween(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _ac, curve: Curves.elasticOut));
    _fade = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _ac, curve: const Interval(0.4, 1.0)));
    _ac.forward();
    Future.delayed(const Duration(milliseconds: 2400), _navigate);
  }

  Future<void> _navigate() async {
    final user = FirebaseAuth.instance.currentUser;
    if (!mounted) return;
    if (user == null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen()));
      return;
    }
    final data = await FB.getUser(user.uid);
    if (!mounted) return;
    if (data == null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen()));
    } else if (data['connected'] == true && data['partnerUid'] != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => HomeScreen(userData: Map<String,dynamic>.from(data))));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => ConnectScreen(userData: Map<String,dynamic>.from(data))));
    }
  }

  @override
  void dispose() { _ac.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.deep,
      body: Stack(children: [
        _BgGlow(),
        Center(
          child: FadeTransition(
            opacity: _fade,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              GestureDetector(
                onTap: () {
                  _taps++;
                  if (_taps >= 3) { _taps = 0; _adminDialog(); }
                },
                child: ScaleTransition(
                  scale: _scale,
                  child: Container(
                    width: 110, height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(colors: [Color(0xFFF0607A), Color(0xFF7A0820)]),
                      boxShadow: [BoxShadow(color: C.rose.withOpacity(0.55), blurRadius: 50, spreadRadius: 8)],
                    ),
                    child: const Center(child: Text('💕', style: TextStyle(fontSize: 52))),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [C.rose, C.gold]).createShader(r),
                child: Text('HeartLink', style: GoogleFonts.cormorantGaramond(
                  fontSize: 46, fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w600, color: Colors.white)),
              ),
              const SizedBox(height: 8),
              const Text('Stay close, no matter the distance',
                style: TextStyle(color: C.muted, fontSize: 13, letterSpacing: 0.5)),
              const SizedBox(height: 60),
              SizedBox(width: 36, height: 36,
                child: CircularProgressIndicator(
                  color: C.rose.withOpacity(0.5), strokeWidth: 2)),
            ]),
          ),
        ),
      ]),
    );
  }

  void _adminDialog() {
    final ctrl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: C.bg2,
      title: const Text('Admin 🔐', style: TextStyle(color: Colors.white)),
      content: TextField(controller: ctrl, obscureText: true,
        style: const TextStyle(color: Colors.white),
        decoration: const InputDecoration(
          hintText: 'admin123', hintStyle: TextStyle(color: C.muted),
          enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: C.border)),
          focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: C.rose)),
        )),
      actions: [
        TextButton(onPressed: ()=>Navigator.pop(context),
          child: const Text('Cancel', style: TextStyle(color: C.muted))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: C.rose),
          onPressed: () {
            if (ctrl.text == 'admin123') {
              Navigator.pop(context);
              // Will navigate to admin tab in home
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('✅ Admin mode! Home → Admin tab'),
                  backgroundColor: C.rose));
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Wrong password!'), backgroundColor: Colors.red));
            }
          },
          child: const Text('Login')),
      ],
    ));
  }
}

class _BgGlow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Positioned.fill(child: CustomPaint(painter: _Painter(size)));
  }
}

class _Painter extends CustomPainter {
  final Size s;
  _Painter(this.s);
  @override
  void paint(Canvas c, Size size) {
    c.drawCircle(Offset(s.width * 0.2, s.height * 0.2), 200,
      Paint()..color = C.rose.withOpacity(0.10)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80));
    c.drawCircle(Offset(s.width * 0.8, s.height * 0.8), 180,
      Paint()..color = const Color(0xFF7830C8).withOpacity(0.08)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80));
  }
  @override bool shouldRepaint(_) => false;
}
