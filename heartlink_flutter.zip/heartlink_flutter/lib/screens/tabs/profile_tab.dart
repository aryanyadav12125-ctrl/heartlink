// ════════════════════════════════
//  TASKS TAB
// ════════════════════════════════
import 'package:flutter/material.dart';
import 'dart:async';
import '../../theme.dart';
import '../../services/fb.dart';

class TasksTab extends StatefulWidget {
  final Map<String,dynamic> ud;
  final Function(int) onCreditsChanged;
  const TasksTab({super.key, required this.ud, required this.onCreditsChanged});
  @override State<TasksTab> createState() => _TasksState();
}

class _TasksState extends State<TasksTab> {
  final List<Map> _ads = [
    {'id':'a1','icon':'🛍️','brand':'ShopNow','title':'Mega Sale 50% Off','desc':'Best deals today','duration':30,'reward':5},
    {'id':'a2','icon':'🍕','brand':'FoodHub','title':'Order & Save!','desc':'Tasty food delivered','duration':60,'reward':10},
    {'id':'a3','icon':'🎮','brand':'GameZone','title':'Play & Win!','desc':'Top games of 2025','duration':120,'reward':20},
  ];
  final Map<String, int> _cooldowns = {};

  // Ad overlay
  bool _showAd = false;
  Map? _currentAd;
  int _adSecs = 0;
  bool _canClaim = false;
  Timer? _adTimer;

  void _watchAd(Map ad) {
    final cooldownEnd = _cooldowns[ad['id']];
    if (cooldownEnd != null && DateTime.now().millisecondsSinceEpoch < cooldownEnd) {
      _snack('⏳ Abhi nahi — 12hr baad!'); return;
    }
    setState(() {
      _currentAd = ad; _adSecs = ad['duration']; _canClaim = false; _showAd = true;
    });
    _adTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() { _adSecs--; if (_adSecs <= 0) { _canClaim = true; t.cancel(); }});
    });
  }

  void _claimAd() {
    if (!_canClaim || _currentAd == null) return;
    _adTimer?.cancel();
    final reward = _currentAd!['reward'] as int;
    final credits = (widget.ud['credits'] ?? 0) + reward;
    widget.ud['credits'] = credits;
    widget.onCreditsChanged(credits);
    FB.updateUser({'credits': credits});
    _cooldowns[_currentAd!['id']] = DateTime.now().millisecondsSinceEpoch + (12 * 3600 * 1000);
    setState(() => _showAd = false);
    _snack('🎉 +$reward ⭐ Credits!');
    Future.delayed(const Duration(hours: 12), () {
      if (mounted) setState(() => _cooldowns.remove(_currentAd!['id']));
    });
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: C.rose, behavior: SnackBarBehavior.floating,
      shape: const StadiumBorder()));

  String _fmt(int s) => s >= 60 ? '${s ~/ 60}:${(s % 60).toString().padLeft(2,'0')}' : '${s}s';

  @override
  void dispose() { _adTimer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      SafeArea(
        child: Column(children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
            decoration: const BoxDecoration(
              color: Color(0xFF0A0510),
              border: Border(bottom: BorderSide(color: C.border))),
            child: Row(children: [
              const Text('Tasks & Earn ⭐', style: TextStyle(color: Colors.white,
                fontSize: 16, fontWeight: FontWeight.w600)),
              const Spacer(),
              Text('⭐ ${widget.ud['credits'] ?? 10}',
                style: const TextStyle(color: C.gold, fontSize: 13)),
            ]),
          ),
          Expanded(
            child: ListView(padding: const EdgeInsets.all(14), children: [
              // Balance
              Container(
                decoration: BoxDecoration(
                  color: C.gold.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: C.gold.withOpacity(0.2))),
                padding: const EdgeInsets.all(14),
                child: Row(children: [
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Balance', style: TextStyle(color: C.muted, fontSize: 11)),
                    Text('${widget.ud['credits'] ?? 10} ⭐',
                      style: const TextStyle(color: C.gold, fontSize: 26, fontWeight: FontWeight.bold)),
                  ]),
                  const Spacer(),
                  const Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text('Draw Cost', style: TextStyle(color: C.muted, fontSize: 11)),
                    Text('1⭐/stroke', style: TextStyle(color: C.muted, fontSize: 13)),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              const Text('WATCH ADS TO EARN', style: TextStyle(color: C.muted, fontSize: 10, letterSpacing: 1)),
              const SizedBox(height: 8),
              ..._ads.map((ad) {
                final onCooldown = _cooldowns.containsKey(ad['id']) &&
                  DateTime.now().millisecondsSinceEpoch < _cooldowns[ad['id']]!;
                final dur = (ad['duration'] as int) >= 60
                  ? '${(ad['duration'] as int) ~/ 60} min'
                  : '${ad['duration']}s';
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: C.cardBox(),
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    Text(ad['icon'], style: const TextStyle(fontSize: 28)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(ad['brand'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                      Text('+${ad['reward']} ⭐ · $dur',
                        style: const TextStyle(color: C.gold, fontSize: 12)),
                      Text(ad['desc'], style: const TextStyle(color: C.muted, fontSize: 11)),
                    ])),
                    GestureDetector(
                      onTap: onCooldown ? null : () => _watchAd(ad),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: onCooldown ? null : C.grad,
                          color: onCooldown ? Colors.white.withOpacity(0.05) : null,
                          borderRadius: BorderRadius.circular(20)),
                        child: Text(onCooldown ? '⏳ 12hr' : 'Watch',
                          style: TextStyle(color: onCooldown ? C.muted : Colors.white,
                            fontSize: 12, fontWeight: FontWeight.w500)),
                      ),
                    ),
                  ]),
                );
              }),
              const SizedBox(height: 8),
              const Text('CHAT TO EARN', style: TextStyle(color: C.muted, fontSize: 10, letterSpacing: 1)),
              const SizedBox(height: 8),
              Container(
                decoration: C.cardBox(),
                padding: const EdgeInsets.all(12),
                child: const Row(children: [
                  Text('💬', style: TextStyle(fontSize: 28)),
                  SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Chat 5 Minutes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                    Text('+2 ⭐', style: TextStyle(color: C.gold, fontSize: 12)),
                    Text('Partner se 5 min baat karo', style: TextStyle(color: C.muted, fontSize: 11)),
                  ])),
                  Text('→ Chat tab', style: TextStyle(color: C.muted, fontSize: 12)),
                ]),
              ),
            ]),
          ),
        ]),
      ),

      // Ad overlay
      if (_showAd && _currentAd != null)
        Positioned.fill(
          child: Container(
            color: Colors.black.withOpacity(0.95),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('ADVERTISEMENT', style: TextStyle(color: C.muted, fontSize: 11, letterSpacing: 2)),
              const SizedBox(height: 14),
              Container(
                width: 320,
                decoration: BoxDecoration(color: C.bg2, borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: C.border)),
                child: Column(children: [
                  Container(
                    height: 160, decoration: BoxDecoration(
                      color: const Color(0xFF1A0A2E),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(22))),
                    child: Center(child: Text(_currentAd!['icon'], style: const TextStyle(fontSize: 60)))),
                  Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(children: [
                      Text(_currentAd!['brand'].toString().toUpperCase(),
                        style: const TextStyle(color: C.muted, fontSize: 10, letterSpacing: 2)),
                      const SizedBox(height: 6),
                      Text(_currentAd!['title'], style: const TextStyle(color: Colors.white,
                        fontSize: 18, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text(_currentAd!['desc'], style: const TextStyle(color: C.muted, fontSize: 13)),
                      const SizedBox(height: 16),
                      Text(_fmt(_adSecs), style: const TextStyle(
                        color: C.rose, fontSize: 36, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: _canClaim ? _claimAd : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: double.infinity, height: 48,
                          decoration: BoxDecoration(
                            gradient: _canClaim ? C.grad : null,
                            color: _canClaim ? null : Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(30)),
                          child: Center(child: Text(
                            'Claim ${_currentAd!['reward']} ⭐',
                            style: TextStyle(
                              color: _canClaim ? Colors.white : C.muted,
                              fontSize: 15, fontWeight: FontWeight.w600))),
                        ),
                      ),
                    ]),
                  ),
                ]),
              ),
            ]),
          ),
        ),
    ]);
  }
}

// ════════════════════════════════
//  PROFILE TAB
// ════════════════════════════════
class ProfileTab extends StatefulWidget {
  final Map<String,dynamic> ud;
  const ProfileTab({super.key, required this.ud});
  @override State<ProfileTab> createState() => _ProfileState();
}

class _ProfileState extends State<ProfileTab> {
  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: C.rose, behavior: SnackBarBehavior.floating,
      shape: const StadiumBorder()));

  void _logout() async {
    await FB.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false);
  }

  void _editName() {
    final ctrl = TextEditingController(text: widget.ud['name']);
    showModalBottomSheet(context: context,
      backgroundColor: C.bg2, shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20,
          MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Edit Name ✏️', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          DarkField(ctrl, 'New name'),
          const SizedBox(height: 14),
          GradBtn('Save ✓', onTap: () {
            final n = ctrl.text.trim();
            if (n.isEmpty) return;
            widget.ud['name'] = n;
            FB.updateUser({'name': n});
            setState(() {});
            Navigator.pop(context);
            _snack('✅ Name updated!');
          }),
        ]),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final ud = widget.ud;
    return SafeArea(
      child: Column(children: [
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0510),
            border: Border(bottom: BorderSide(color: C.border))),
          child: Row(children: [
            const Text('My Profile', style: TextStyle(color: Colors.white,
              fontSize: 16, fontWeight: FontWeight.w600)),
            const Spacer(),
            GestureDetector(onTap: _editName,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: C.border)),
                child: const Text('✏️ Edit', style: TextStyle(color: Colors.white70, fontSize: 12)))),
          ]),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(14), children: [
            // Avatar + info
            Center(child: Column(children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: C.grad,
                  border: Border.all(color: C.rose.withOpacity(0.4), width: 3)),
                child: const Center(child: Text('😊', style: TextStyle(fontSize: 36)))),
              const SizedBox(height: 10),
              Text(ud['name'] ?? '—', style: const TextStyle(
                color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600)),
              Text(ud['phone'] ?? '—', style: const TextStyle(color: C.muted, fontSize: 13)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: C.rose.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: C.rose.withOpacity(0.3))),
                child: Text('Code: ${ud['code'] ?? '—'}',
                  style: const TextStyle(color: C.rose, fontSize: 13, letterSpacing: 2))),
            ])),
            const SizedBox(height: 18),

            // Partner
            Container(
              decoration: C.cardBox(),
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('PARTNER', style: TextStyle(color: C.muted, fontSize: 10, letterSpacing: 1.5)),
                const SizedBox(height: 10),
                Row(children: [
                  Container(width: 44, height: 44,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [Color(0xFFB060F0), Color(0xFF7030C0)])),
                    child: const Center(child: Text('💖', style: TextStyle(fontSize: 22)))),
                  const SizedBox(width: 12),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(ud['partnerName'] ?? 'No partner',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                    Text(ud['partnerCode'] != null ? 'Code: ${ud['partnerCode']}' : 'Connect karo',
                      style: const TextStyle(color: C.muted, fontSize: 12)),
                  ]),
                ]),
              ]),
            ),
            const SizedBox(height: 12),

            // Stats
            Container(
              decoration: C.cardBox(),
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('STATS', style: TextStyle(color: C.muted, fontSize: 10, letterSpacing: 1.5)),
                const SizedBox(height: 10),
                GridView.count(
                  crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 2.2,
                  children: [
                    _Stat('${ud['credits'] ?? 10}', '⭐ Credits', C.gold),
                    _Stat('${ud['totalMsgs'] ?? 0}', '💬 Messages', C.rose),
                    _Stat('${ud['totalDraws'] ?? 0}', '🎨 Drawings', C.purple),
                    _Stat('${ud['totalAds'] ?? 0}', '📺 Ads', C.green),
                  ],
                ),
              ]),
            ),
            const SizedBox(height: 20),

            GestureDetector(
              onTap: _logout,
              child: Container(
                height: 50, decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: C.border)),
                child: const Center(child: Text('🚪 Logout',
                  style: TextStyle(color: Colors.white70, fontSize: 14)))),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _Stat(String val, String label, Color color) => Container(
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: color.withOpacity(0.2))),
    padding: const EdgeInsets.all(10),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(val, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: C.muted, fontSize: 10)),
    ]),
  );
}
