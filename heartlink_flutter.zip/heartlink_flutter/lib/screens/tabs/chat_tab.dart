import 'package:flutter/material.dart';
import 'dart:async';
import '../../theme.dart';
import '../../services/fb.dart';

class ChatTab extends StatefulWidget {
  final Map<String,dynamic> ud;
  final Function(int) onCreditsChanged;
  const ChatTab({super.key, required this.ud, required this.onCreditsChanged});
  @override State<ChatTab> createState() => _State();
}

class _State extends State<ChatTab> {
  final _inp = TextEditingController();
  final _scroll = ScrollController();
  final List<Map> _msgs = [];
  Timer? _timer;
  int _secs = 300; // 5 min
  bool _timerRunning = false;

  final _replies = ['Miss you 💕','Haha 😄','Sach mein?','Aww 🥺','Love you too!',
    'Kya hua? Bata!','😂😂','Haan bilkul!','Kab miloge?','Forever yours 💞'];

  @override
  void initState() {
    super.initState();
    if (widget.ud['partnerUid'] != null) {
      FB.chatStream(widget.ud['partnerUid']).listen((event) {
        final d = event.snapshot.value as Map?;
        if (d == null || d['uid'] == FB.uid) return;
        setState(() => _msgs.add(Map<String,dynamic>.from(d)));
        _scrollDown();
      });
    }
    _startTimer();
  }

  void _startTimer() {
    if (_timerRunning) return;
    _timerRunning = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _secs--);
      if (_secs <= 0) {
        _secs = 300;
        final credits = (widget.ud['credits'] ?? 0) + 2;
        widget.onCreditsChanged(credits);
        FB.updateUser({'credits': credits});
        _showSnack('🎉 +2 ⭐ Chat credits!');
      }
    });
  }

  void _send() {
    final txt = _inp.text.trim();
    if (txt.isEmpty) return;
    _inp.clear();
    final msg = {'uid': FB.uid, 'name': widget.ud['name'], 'text': txt,
      'time': DateTime.now().millisecondsSinceEpoch};
    setState(() => _msgs.add(msg));
    _scrollDown();
    if (widget.ud['partnerUid'] != null) {
      FB.sendMsg(widget.ud['partnerUid'], txt, widget.ud['name']);
    } else {
      // Demo reply
      Future.delayed(Duration(milliseconds: 700 + (300 * (_replies.length % 3))), () {
        if (!mounted) return;
        final r = _replies[_msgs.length % _replies.length];
        setState(() => _msgs.add({'uid': 'partner', 'name': widget.ud['partnerName'] ?? 'Partner',
          'text': r, 'time': DateTime.now().millisecondsSinceEpoch}));
        _scrollDown();
      });
    }
  }

  void _scrollDown() => Future.delayed(const Duration(milliseconds: 100), () {
    if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  });

  void _showSnack(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: C.rose, behavior: SnackBarBehavior.floating,
      shape: const StadiumBorder()));

  String _fmt(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2,'0')}';

  @override
  void dispose() { _timer?.cancel(); _inp.dispose(); _scroll.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(children: [
        // Header
        Container(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0510),
            border: Border(bottom: BorderSide(color: C.border))),
          child: Row(children: [
            Container(width: 36, height: 36, decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [Color(0xFFB060F0), Color(0xFF7030C0)])),
              child: const Center(child: Text('💖', style: TextStyle(fontSize: 18)))),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.ud['partnerName'] ?? 'Partner',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
              Row(children: [
                Container(width: 5, height: 5, margin: const EdgeInsets.only(right: 4),
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: C.green)),
                const Text('Online', style: TextStyle(color: C.muted, fontSize: 11)),
              ]),
            ]),
            const Spacer(),
            Text('⭐ ${widget.ud['credits'] ?? 10}',
              style: const TextStyle(color: C.gold, fontSize: 13)),
          ]),
        ),

        // Timer bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          color: C.gold.withOpacity(0.07),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('💬 5 min chat → +2 ⭐  |  Timer: ',
              style: TextStyle(color: C.gold, fontSize: 12)),
            Text(_fmt(_secs), style: const TextStyle(color: C.gold, fontSize: 12, fontWeight: FontWeight.bold)),
          ]),
        ),

        // Messages
        Expanded(
          child: _msgs.isEmpty
            ? const Center(child: Text('💌 Chat shuru karo credits kamao!',
                style: TextStyle(color: C.muted, fontSize: 14)))
            : ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.all(12),
                itemCount: _msgs.length,
                itemBuilder: (_, i) {
                  final m = _msgs[i];
                  final isMe = m['uid'] == FB.uid;
                  final t = DateTime.fromMillisecondsSinceEpoch(m['time'] as int);
                  return Align(
                    alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      child: Column(
                        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              gradient: isMe ? C.grad : null,
                              color: isMe ? null : Colors.white.withOpacity(0.08),
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(18),
                                topRight: const Radius.circular(18),
                                bottomLeft: Radius.circular(isMe ? 18 : 4),
                                bottomRight: Radius.circular(isMe ? 4 : 18),
                              ),
                              border: isMe ? null : Border.all(color: C.border),
                            ),
                            child: Text(m['text'] as String,
                              style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.4)),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: Text(
                              '${t.hour}:${t.minute.toString().padLeft(2,'0')}${isMe ? ' ✓' : ''}',
                              style: const TextStyle(color: C.muted, fontSize: 10)),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
        ),

        // Input bar
        Container(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0510),
            border: Border(top: BorderSide(color: C.border))),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _inp,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: 'Kuch sweet likho… 💕',
                  hintStyle: const TextStyle(color: C.muted),
                  filled: true, fillColor: Colors.white.withOpacity(0.06),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _send,
              child: Container(
                width: 42, height: 42,
                decoration: const BoxDecoration(shape: BoxShape.circle, gradient: C.grad),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}
