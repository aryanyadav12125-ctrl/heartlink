import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'dart:async';
import 'dart:convert';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:screenshot/screenshot.dart';
import '../../theme.dart';
import '../../services/fb.dart';

class DrawTab extends StatefulWidget {
  final Map<String,dynamic> ud;
  final Function(int) onCreditsChanged;
  const DrawTab({super.key, required this.ud, required this.onCreditsChanged});
  @override State<DrawTab> createState() => _State();
}

class _State extends State<DrawTab> {
  // Drawing state
  final List<_Stroke> _strokes = [];
  _Stroke? _current;
  Color _color = const Color(0xFFF0607A);
  double _size = 4;
  bool _eraser = false;
  int _strokeCount = 0;

  // Screenshot for sending to lock screen
  final _screenshotCtrl = ScreenshotController();

  // Firebase listener
  StreamSubscription? _drawSub;
  bool _listening = false;

  // Send timer — batch strokes every 200ms
  Timer? _sendTimer;
  final List<Map> _pending = [];

  @override
  void initState() {
    super.initState();
    _startListening();
  }

  void _startListening() {
    if (widget.ud['partnerUid'] == null || _listening) return;
    _listening = true;
    _drawSub = FB.drawStream(widget.ud['partnerUid']).listen((event) {
      final d = event.snapshot.value as Map?;
      if (d == null || d['uid'] == FB.uid) return;
      setState(() {
        if (d['type'] == 'dot') {
          _strokes.add(_Stroke(
            color: Color(int.parse(d['color'])),
            size: (d['size'] as num).toDouble(),
            eraser: d['eraser'] as bool,
            points: [Offset((d['x'] as num).toDouble(), (d['y'] as num).toDouble())],
          ));
        } else if (d['type'] == 'line') {
          final last = _strokes.isEmpty ? null : _strokes.last;
          if (last != null && last.uid == d['uid']) {
            last.points.add(Offset((d['x'] as num).toDouble(), (d['y'] as num).toDouble()));
          }
        }
      });
    });
  }

  void _onPanStart(DragStartDetails det) {
    if (!_checkCredits()) return;
    final stroke = _Stroke(
      color: _eraser ? C.deep : _color,
      size: _size,
      eraser: _eraser,
      points: [det.localPosition],
      uid: FB.uid,
    );
    setState(() { _current = stroke; _strokes.add(stroke); });
    _queueStroke({'type': 'dot', 'x': det.localPosition.dx, 'y': det.localPosition.dy,
      'color': _color.value.toString(), 'size': _size, 'eraser': _eraser});
  }

  void _onPanUpdate(DragUpdateDetails det) {
    if (_current == null || !_checkCredits(silent: true)) return;
    setState(() => _current!.points.add(det.localPosition));
    _queueStroke({'type': 'line', 'x': det.localPosition.dx, 'y': det.localPosition.dy,
      'color': _color.value.toString(), 'size': _size, 'eraser': _eraser});
  }

  void _onPanEnd(DragEndDetails _) {
    if (_current == null) return;
    setState(() { _current = null; _strokeCount++; });
    _deductCredit();
    _flushStrokes();
    // Send screenshot to partner's lock screen every 3 strokes
    if (_strokeCount % 3 == 0) _sendToLockScreen();
  }

  bool _checkCredits({bool silent = false}) {
    if ((widget.ud['credits'] ?? 0) <= 0) {
      if (!silent) _showSnack('⚠️ Credits khatam! Tasks mein ads dekho');
      return false;
    }
    return true;
  }

  void _deductCredit() {
    final c = ((widget.ud['credits'] ?? 0) - 1).clamp(0, 9999);
    widget.ud['credits'] = c;
    widget.onCreditsChanged(c);
    FB.updateUser({'credits': c});
  }

  void _queueStroke(Map stroke) {
    _pending.add(stroke);
    _sendTimer?.cancel();
    _sendTimer = Timer(const Duration(milliseconds: 50), _flushStrokes);
  }

  void _flushStrokes() {
    if (widget.ud['partnerUid'] == null) return;
    for (final s in _pending) {
      FB.sendStroke(widget.ud['partnerUid'], s);
    }
    _pending.clear();
  }

  // ⭐ KEY FEATURE: Send drawing screenshot to partner's lock screen
  Future<void> _sendToLockScreen() async {
    if (widget.ud['partnerUid'] == null) return;
    try {
      final image = await _screenshotCtrl.capture(pixelRatio: 1.0);
      if (image == null) return;
      final b64 = base64Encode(image);
      await FB.sendDrawImage(widget.ud['partnerUid'], b64, widget.ud['name']);

      // Show full-screen notification on THIS device for demo
      // On partner's device — Firebase listener in main.dart triggers this
      await AwesomeNotifications().createNotification(
        content: NotificationContent(
          id: DateTime.now().millisecondsSinceEpoch % 100000,
          channelKey: 'draw_channel',
          title: '💕 ${widget.ud['name']} ne drawing bheji!',
          body: 'Lock screen par dekho',
          bigPicture: 'data:image/png;base64,$b64',
          notificationLayout: NotificationLayout.BigPicture,
          fullScreenIntent: true, // ⬅️ SHOWS ON LOCK SCREEN!
          autoDismissible: false,
          displayOnForeground: false,
          displayOnBackground: true,
          category: NotificationCategory.Call,
          backgroundColor: C.deep,
          color: C.rose,
        ),
      );
    } catch (e) {
      debugPrint('Screenshot error: $e');
    }
  }

  void _clear() {
    setState(() { _strokes.clear(); _strokeCount = 0; });
    if (widget.ud['partnerUid'] != null) FB.clearDraw(widget.ud['partnerUid']);
  }

  void _showSnack(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: C.rose, behavior: SnackBarBehavior.floating,
      shape: const StadiumBorder()));

  @override
  void dispose() {
    _drawSub?.cancel(); _sendTimer?.cancel(); super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(children: [
        // Top bar
        Container(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0510),
            border: Border(bottom: BorderSide(color: C.border))),
          child: Column(children: [
            Row(children: [
              const Text('🎨 Live Draw', style: TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600,
                fontFamily: 'serif', fontStyle: FontStyle.italic)),
              const Spacer(),
              Text('⭐ ${widget.ud['credits'] ?? 10}',
                style: const TextStyle(color: C.gold, fontSize: 13)),
            ]),
            const SizedBox(height: 8),
            // Tools
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                ...[C.rose, C.purple, const Color(0xFF60D4F0),
                    const Color(0xFFF0E060), const Color(0xFF60F0A0), Colors.white]
                  .map((c) => _ColorDot(c, _color == c && !_eraser, () {
                    setState(() { _color = c; _eraser = false; }); })),
                const SizedBox(width: 6),
                _ToolBtn('⬜ Erase', _eraser, () => setState(() => _eraser = !_eraser)),
                const SizedBox(width: 4),
                ...[3.0, 7.0, 13.0].map((s) => _SizeDot(s, _size == s, () => setState(()=>_size=s))),
                const SizedBox(width: 6),
                _ToolBtn('🗑', false, _clear),
                const SizedBox(width: 6),
                _ToolBtn('📤 Send to Lock Screen', false, _sendToLockScreen,
                  color: C.rose.withOpacity(0.8)),
              ]),
            ),
          ]),
        ),

        // Canvas - Screenshot wrapper for capturing
        Expanded(
          child: Screenshot(
            controller: _screenshotCtrl,
            child: GestureDetector(
              onPanStart: _onPanStart,
              onPanUpdate: _onPanUpdate,
              onPanEnd: _onPanEnd,
              child: Container(
                width: double.infinity,
                color: const Color(0xFF0C0610),
                child: Stack(children: [
                  // Ambient glow
                  Positioned.fill(
                    child: CustomPaint(painter: _AmbientPainter())),
                  // Drawing canvas
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _DrawPainter(_strokes),
                    ),
                  ),
                  // Watermark
                  Center(
                    child: Opacity(
                      opacity: _strokes.isEmpty ? 0.15 : 0,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const Text('💕', style: TextStyle(fontSize: 60)),
                        const SizedBox(height: 8),
                        Text('Yahan draw karo!',
                          style: TextStyle(color: C.muted, fontSize: 16)),
                        Text('Partner ki lock screen par dikhega',
                          style: TextStyle(color: C.muted.withOpacity(0.6), fontSize: 12)),
                      ]),
                    ),
                  ),
                  // Live indicator
                  if (_strokes.isNotEmpty)
                    Positioned(top: 10, right: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: C.rose.withOpacity(0.9),
                          borderRadius: BorderRadius.circular(20)),
                        child: const Row(mainAxisSize: MainAxisSize.min, children: [
                          _BlinkDot(), SizedBox(width: 5),
                          Text('LIVE', style: TextStyle(color: Colors.white,
                            fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                        ]),
                      )),
                ]),
              ),
            ),
          ),
        ),

        // Bottom bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0510),
            border: Border(top: BorderSide(color: C.border))),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _Stat('$_strokeCount', 'Strokes'),
            _Stat('1⭐', '/stroke'),
            _Stat('${widget.ud['credits'] ?? 10}⭐', 'Left'),
          ]),
        ),
      ]),
    );
  }

  Widget _ColorDot(Color c, bool active, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 26, height: 26, margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: c,
        border: Border.all(color: active ? Colors.white : Colors.transparent, width: 2.5),
      ),
    ),
  );

  Widget _SizeDot(double s, bool active, VoidCallback onTap) {
    final d = s == 3.0 ? 8.0 : s == 7.0 ? 13.0 : 18.0;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: d, height: d, margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active ? C.rose : C.muted.withOpacity(0.5)),
      ),
    );
  }

  Widget _ToolBtn(String label, bool active, VoidCallback onTap, {Color? color}) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        margin: const EdgeInsets.only(right: 4),
        decoration: BoxDecoration(
          color: active ? C.rose.withOpacity(0.2) : (color?.withOpacity(0.15) ?? Colors.white.withOpacity(0.05)),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? C.rose : (color ?? C.border.withOpacity(0.3))),
        ),
        child: Text(label, style: TextStyle(
          color: active ? C.rose : (color ?? Colors.white.withOpacity(0.6)),
          fontSize: 11)),
      ),
    );

  Widget _Stat(String val, String label) => Column(children: [
    Text(val, style: const TextStyle(color: C.gold, fontSize: 16, fontWeight: FontWeight.w600)),
    Text(label, style: const TextStyle(color: C.muted, fontSize: 10)),
  ]);
}

// ── Stroke model ──
class _Stroke {
  final Color color;
  final double size;
  final bool eraser;
  final List<Offset> points;
  String? uid;
  _Stroke({required this.color, required this.size, required this.eraser,
    required this.points, this.uid});
}

// ── Draw painter ──
class _DrawPainter extends CustomPainter {
  final List<_Stroke> strokes;
  _DrawPainter(this.strokes);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in strokes) {
      final paint = Paint()
        ..color = s.eraser ? const Color(0xFF0C0610) : s.color
        ..strokeWidth = s.size
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke
        ..blendMode = s.eraser ? BlendMode.clear : BlendMode.srcOver;

      if (s.points.length == 1) {
        canvas.drawCircle(s.points.first, s.size / 2, paint..style = PaintingStyle.fill);
      } else {
        final path = Path()..moveTo(s.points.first.dx, s.points.first.dy);
        for (int i = 1; i < s.points.length; i++) {
          path.lineTo(s.points[i].dx, s.points[i].dy);
        }
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DrawPainter old) => old.strokes != strokes || old.strokes.length != strokes.length;
}

class _AmbientPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawCircle(
      Offset(size.width * 0.8, size.height * 0.2), 120,
      Paint()..color = C.rose.withOpacity(0.04)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60));
    canvas.drawCircle(
      Offset(size.width * 0.2, size.height * 0.7), 100,
      Paint()..color = C.purple.withOpacity(0.04)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60));
  }
  @override bool shouldRepaint(_) => false;
}

class _BlinkDot extends StatefulWidget {
  const _BlinkDot();
  @override State<_BlinkDot> createState() => _BlinkState();
}
class _BlinkState extends State<_BlinkDot> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override void initState() { super.initState(); _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true); }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override Widget build(BuildContext c) => FadeTransition(opacity: _c,
    child: Container(width: 6, height: 6, decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white)));
}
