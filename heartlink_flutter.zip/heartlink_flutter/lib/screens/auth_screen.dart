import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import '../services/fb.dart';
import 'connect_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _State();
}

class _State extends State<AuthScreen> {
  int _step = 0;
  final _phone = TextEditingController();
  final _name = TextEditingController();
  final _otps = List.generate(4, (_) => TextEditingController());
  final _foci = List.generate(4, (_) => FocusNode());
  String _vId = '';
  bool _loading = false;

  @override
  void dispose() {
    _phone.dispose(); _name.dispose();
    for (var c in _otps) c.dispose();
    for (var f in _foci) f.dispose();
    super.dispose();
  }

  Future<void> _sendOTP() async {
    if (_phone.text.trim().length < 8) { _err('Valid phone enter karo (+91...)'); return; }
    setState(() => _loading = true);
    await FB.sendOTP(
      _phone.text.trim(),
      onSent: (id) => setState(() { _vId = id; _loading = false; _step = 1; }),
      onError: (e) { setState(() => _loading = false); _err(e); },
    );
  }

  Future<void> _verifyOTP() async {
    final otp = _otps.map((c) => c.text).join();
    if (otp.length < 4) return;
    setState(() => _loading = true);
    try {
      final cred = await FB.verifyOTP(_vId, otp);
      final data = await FB.getUser(cred.user!.uid);
      if (!mounted) return;
      if (data != null && data['name'] != null) {
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => ConnectScreen(userData: Map<String,dynamic>.from(data))));
      } else {
        setState(() { _loading = false; _step = 2; });
      }
    } catch(e) {
      setState(() => _loading = false);
      _err('Wrong OTP!');
    }
  }

  Future<void> _saveName() async {
    if (_name.text.trim().isEmpty) { _err('Name enter karo'); return; }
    setState(() => _loading = true);
    final code = DateTime.now().millisecondsSinceEpoch.toString().substring(7);
    await FB.saveUser(_name.text.trim(), code, _phone.text.trim());
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(
      builder: (_) => ConnectScreen(userData: {
        'name': _name.text.trim(), 'code': code,
        'phone': _phone.text.trim(), 'credits': 10,
      })));
  }

  void _err(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: Colors.redAccent));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.deep,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Container(
              decoration: C.cardBox(radius: 24),
              padding: const EdgeInsets.all(24),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // Logo
                Center(child: Column(children: [
                  const Text('💕', style: TextStyle(fontSize: 52)),
                  const SizedBox(height: 8),
                  ShaderMask(
                    shaderCallback: (r) => const LinearGradient(
                      colors: [C.rose, C.gold]).createShader(r),
                    child: Text('HeartLink', style: GoogleFonts.cormorantGaramond(
                      fontSize: 34, fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w600, color: Colors.white)),
                  ),
                ])),
                const SizedBox(height: 24),

                if (_step == 0) ...[
                  _title('Login 📱'),
                  _sub('Phone number se login karo'),
                  const SizedBox(height: 14),
                  DarkField(_phone, '+91 98765 43210', type: TextInputType.phone),
                  const SizedBox(height: 16),
                  GradBtn('Send OTP 📲', onTap: _loading ? null : _sendOTP),
                ],

                if (_step == 1) ...[
                  _title('Verify 🔐'),
                  _sub('OTP bheja: ${_phone.text}'),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(4, (i) => _otpBox(i)),
                  ),
                  const SizedBox(height: 20),
                  GradBtn('Verify ✓', onTap: _loading ? null : _verifyOTP),
                  const SizedBox(height: 8),
                  Center(child: TextButton(
                    onPressed: () => setState(() => _step = 0),
                    child: const Text('← Number badlo', style: TextStyle(color: C.muted)))),
                ],

                if (_step == 2) ...[
                  _title('Apna Naam 😊'),
                  _sub('Partner tumhe kaise bulaye?'),
                  const SizedBox(height: 14),
                  DarkField(_name, 'e.g. Priya', type: TextInputType.name),
                  const SizedBox(height: 16),
                  GradBtn('Continue →', onTap: _loading ? null : _saveName),
                ],

                if (_loading) ...[
                  const SizedBox(height: 14),
                  const Center(child: CircularProgressIndicator(color: C.rose, strokeWidth: 2)),
                ],
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Text _title(String t) => Text(t, style: GoogleFonts.cormorantGaramond(
    fontSize: 24, color: Colors.white, fontWeight: FontWeight.w600));
  Widget _sub(String t) => Padding(padding: const EdgeInsets.only(top: 3, bottom: 0),
    child: Text(t, style: const TextStyle(color: C.muted, fontSize: 12)));

  Widget _otpBox(int i) => SizedBox(
    width: 58, height: 66,
    child: TextField(
      controller: _otps[i], focusNode: _foci[i],
      textAlign: TextAlign.center, maxLength: 1,
      keyboardType: TextInputType.number,
      style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
      decoration: InputDecoration(counterText: '',
        filled: true, fillColor: Colors.white.withOpacity(0.07),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: C.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: C.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: C.rose, width: 1.5))),
      onChanged: (v) {
        if (v.isNotEmpty && i < 3) _foci[i+1].requestFocus();
        if (v.isEmpty && i > 0) _foci[i-1].requestFocus();
        if (i == 3 && v.isNotEmpty) _verifyOTP();
      },
    ),
  );
}
