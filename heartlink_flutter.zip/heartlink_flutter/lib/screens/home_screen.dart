import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import 'tabs/chat_tab.dart';
import 'tabs/draw_tab.dart';
import 'tabs/tasks_tab.dart';
import 'tabs/profile_tab.dart';

class HomeScreen extends StatefulWidget {
  final Map<String,dynamic> userData;
  const HomeScreen({super.key, required this.userData});
  @override State<HomeScreen> createState() => _State();
}

class _State extends State<HomeScreen> {
  int _tab = 0;
  late Map<String,dynamic> _ud;
  int _notifCount = 0;

  @override
  void initState() {
    super.initState();
    _ud = Map<String,dynamic>.from(widget.userData);
    _ud['credits'] ??= 10;
  }

  void _onCreditsChanged(int credits) => setState(() => _ud['credits'] = credits);
  void _addNotif() => setState(() => _notifCount++);

  @override
  Widget build(BuildContext context) {
    final tabs = [
      _HomeTab(ud: _ud, onTabChange: (i) => setState(()=>_tab=i)),
      ChatTab(ud: _ud, onCreditsChanged: _onCreditsChanged),
      DrawTab(ud: _ud, onCreditsChanged: _onCreditsChanged),
      TasksTab(ud: _ud, onCreditsChanged: _onCreditsChanged),
      ProfileTab(ud: _ud),
    ];

    return Scaffold(
      backgroundColor: C.deep,
      body: tabs[_tab],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A0510).withOpacity(0.97),
          border: const Border(top: BorderSide(color: C.border)),
        ),
        child: SafeArea(
          top: false,
          child: Row(children: [
            _NavBtn('🏠', 'Home', 0),
            _NavBtn('💬', 'Chat', 1),
            _NavBtn('🎨', 'Draw', 2),
            _NavBtn('⭐', 'Tasks', 3),
            _NavBtn('👤', 'Profile', 4),
          ]),
        ),
      ),
    );
  }

  Widget _NavBtn(String icon, String label, int idx) {
    final active = _tab == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = idx),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          color: Colors.transparent,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(
              fontSize: 9, letterSpacing: 0.5,
              color: active ? C.rose : C.muted,
              fontWeight: active ? FontWeight.w600 : FontWeight.normal)),
          ]),
        ),
      ),
    );
  }
}

// ── HOME TAB ──
class _HomeTab extends StatelessWidget {
  final Map<String,dynamic> ud;
  final Function(int) onTabChange;
  const _HomeTab({required this.ud, required this.onTabChange});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
          child: Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Good day,', style: TextStyle(color: C.muted, fontSize: 12)),
              Text(ud['name'] ?? '—', style: GoogleFonts.cormorantGaramond(
                fontSize: 26, fontStyle: FontStyle.italic, color: Colors.white)),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: () => onTabChange(3),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: C.gold.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: C.gold.withOpacity(0.3)),
                ),
                child: Text('⭐ ${ud['credits'] ?? 10}',
                  style: const TextStyle(color: C.gold, fontSize: 14, fontWeight: FontWeight.w500)),
              ),
            ),
          ]),
        ),

        // Partner banner
        if (ud['connected'] == true)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Container(
              decoration: C.cardBox(),
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(width: 46, height: 46, decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [Color(0xFFB060F0), Color(0xFF7030C0)])),
                  child: const Center(child: Text('💖', style: TextStyle(fontSize: 22)))),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(ud['partnerName'] ?? 'Partner',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 15)),
                  Row(children: [
                    Container(width: 6, height: 6, margin: const EdgeInsets.only(right: 5),
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: C.green)),
                    const Text('Connected', style: TextStyle(color: C.muted, fontSize: 12)),
                  ]),
                ]),
                const Spacer(),
                const Text('💞', style: TextStyle(fontSize: 22)),
              ]),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Container(
              decoration: BoxDecoration(
                color: C.rose.withOpacity(0.06),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: C.border, style: BorderStyle.solid),
              ),
              padding: const EdgeInsets.all(16),
              child: const Center(child: Text('Partner connected nahi 💭\nProfile mein connect karo',
                textAlign: TextAlign.center,
                style: TextStyle(color: C.muted, fontSize: 13, height: 1.6))),
            ),
          ),

        // Feature grid
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.2,
              children: [
                _FeatCard('💬', 'Chat', 'Credits kamao', C.rose, () => onTabChange(1)),
                _FeatCard('🎨', 'Draw', 'Partner ki screen par', C.purple, () => onTabChange(2)),
                _FeatCard('⭐', 'Tasks', 'Ads → Credits', C.gold, () => onTabChange(3)),
                _FeatCard('👤', 'Profile', 'Edit your info', C.green, () => onTabChange(4)),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget _FeatCard(String icon, String title, String sub, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.07),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(icon, style: const TextStyle(fontSize: 36)),
          const SizedBox(height: 6),
          Text(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
          Text(sub, style: TextStyle(color: color.withOpacity(0.7), fontSize: 11)),
        ]),
      ),
    );
  }
}
