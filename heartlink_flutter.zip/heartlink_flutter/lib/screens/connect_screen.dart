import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import '../services/fb.dart';
import 'home_screen.dart';

class ConnectScreen extends StatefulWidget {
  final Map<String,dynamic> userData;
  const ConnectScreen({super.key, required this.userData});
  @override State<ConnectScreen> createState() => _State();
}

class _State extends State<ConnectScreen> {
  final _code = TextEditingController();
  final _pname = TextEditingController();
  bool _loading = false;
  late Map<String,dynamic> _ud;

  @override
  void initState() {
    super.initState();
    _ud = Map<String,dynamic>.from(widget.userData);
    // Listen for incoming requests
    FB.requestsStream().listen((event) {
      final d = event.snapshot.value as Map?;
      if (d == null) return;
      _requestDialog(d['fromName'] as String, d['fromUid'] as String, d['fromCode'] as String);
      event.snapshot.ref.remove();
    });
  }

  void _requestDialog(String name, String fromUid, String fromCode) {
    if (!mounted) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      backgroundColor: C.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text('💑 Connect Request!', style: GoogleFonts.cormorantGaramond(
        color: Colors.white, fontSize: 20)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('💕', style: TextStyle(fontSize: 40)),
        const SizedBox(height: 8),
        Text('$name\nne aapko connect karna chahta/chahti hai!',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70, fontSize: 14)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('Decline', style: TextStyle(color: C.muted))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: C.rose, shape: const StadiumBorder()),
          onPressed: () async {
            Navigator.pop(context);
            await FB.acceptConnect(fromUid);
            _ud['partnerUid'] = fromUid;
            _ud['partnerName'] = name;
            _ud['partnerCode'] = fromCode;
            _ud['connected'] = true;
            if (!mounted) return;
            Navigator.pushReplacement(context, MaterialPageRoute(
              builder: (_) => HomeScreen(userData: _ud)));
          },
          child: const Text('Accept 💞')),
      ],
    ));
  }

  Future<void> _sendRequest() async {
    final code = _code.text.trim().toUpperCase();
    if (code.length < 4) { _err('Valid code enter karo'); return; }
    setState(() => _loading = true);
    final pUid = await FB.findByCode(code);
    if (pUid == null) { setState(()=>_loading=false); _err('Code nahi mila!'); return; }
    if (pUid == FB.uid) { setState(()=>_loading=false); _err('Apna hi code nahi!'); return; }
    await FB.sendRequest(pUid, _ud['name'], _ud['code']);
    setState(() => _loading = false);
    _msg('💌 Request bheji!');
    // Also listen if they accept
    FB.db.child('users/${FB.uid}').onValue.listen((e) {
      final d = e.snapshot.value as Map?;
      if (d != null && d['connected'] == true) {
        _ud['partnerUid'] = pUid;
        _ud['partnerName'] = _pname.text.trim().isEmpty ? 'Partner' : _pname.text.trim();
        _ud['partnerCode'] = code;
        _ud['connected'] = true;
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => HomeScreen(userData: _ud)));
      }
    });
  }

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: C.rose, shape: const StadiumBorder(),
      behavior: SnackBarBehavior.floating));
  void _err(String m) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(m), backgroundColor: Colors.redAccent, shape: const StadiumBorder(),
      behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.deep,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Container(
              decoration: C.cardBox(radius: 24),
              padding: const EdgeInsets.all(22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Center(child: Text('Connect 💞', style: GoogleFonts.cormorantGaramond(
                  fontSize: 26, color: Colors.white, fontWeight: FontWeight.w600))),
                const Center(child: Text('Partner ko code share karo ya unka code enter karo',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: C.muted, fontSize: 12))),
                const SizedBox(height: 18),

                // My code box
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: C.rose.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: C.rose, width: 1.5),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    Text(_ud['code'] ?? '——', style: GoogleFonts.cormorantGaramond(
                      fontSize: 40, color: C.rose, letterSpacing: 10)),
                    const Text('Apna code', style: TextStyle(color: C.muted, fontSize: 11)),
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: _ud['code'] ?? ''));
                        _msg('📋 Copied!');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                        decoration: BoxDecoration(
                          color: C.rose.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: C.border),
                        ),
                        child: const Text('📋 Copy Code',
                          style: TextStyle(color: C.rose, fontSize: 12, fontWeight: FontWeight.w500)),
                      ),
                    ),
                  ]),
                ),

                const SizedBox(height: 16),
                Row(children: [
                  const Expanded(child: Divider(color: C.border)),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('ya', style: TextStyle(color: C.muted, fontSize: 12))),
                  const Expanded(child: Divider(color: C.border)),
                ]),
                const SizedBox(height: 16),

                const Text('PARTNER KA CODE', style: TextStyle(color: C.muted, fontSize: 10, letterSpacing: 1)),
                const SizedBox(height: 6),
                DarkField(_code, 'e.g. A1B2C3', center: true, caps: true, maxLength: 8),
                const SizedBox(height: 10),
                DarkField(_pname, 'Partner ka naam (optional)'),
                const SizedBox(height: 16),
                GradBtn('Send Request 💌', onTap: _loading ? null : _sendRequest),

                if (_loading) ...[
                  const SizedBox(height: 14),
                  const Center(child: CircularProgressIndicator(color: C.rose, strokeWidth: 2)),
                  const SizedBox(height: 8),
                  const Center(child: Text('Request bhej raha hai...', style: TextStyle(color: C.muted, fontSize: 12))),
                ],
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
