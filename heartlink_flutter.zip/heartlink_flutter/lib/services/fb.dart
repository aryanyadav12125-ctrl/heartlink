import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class FB {
  static final auth = FirebaseAuth.instance;
  static final db = FirebaseDatabase.instance.ref();
  static String? get uid => auth.currentUser?.uid;

  // ── AUTH ──
  static Future<String?> sendOTP(String phone,
      {required Function(String) onSent, required Function(String) onError}) async {
    String? vId;
    await auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async => await auth.signInWithCredential(cred),
      verificationFailed: (e) => onError(e.message ?? 'Error'),
      codeSent: (id, _) { vId = id; onSent(id); },
      codeAutoRetrievalTimeout: (_) {},
    );
    return vId;
  }

  static Future<UserCredential> verifyOTP(String vId, String otp) =>
    auth.signInWithCredential(PhoneAuthProvider.credential(verificationId: vId, smsCode: otp));

  // ── USER ──
  static Future<Map?> getUser([String? id]) async {
    final snap = await db.child('users/${id ?? uid}').get();
    return snap.value as Map?;
  }

  static Future<void> saveUser(String name, String code, String phone) =>
    db.child('users/$uid').set({
      'name': name, 'code': code, 'phone': phone,
      'credits': 10, 'createdAt': ServerValue.timestamp,
    }).then((_) => db.child('codes/$code').set(uid));

  static Future<void> updateUser(Map<String, dynamic> data) =>
    db.child('users/$uid').update(data);

  // ── CONNECT ──
  static Future<String?> findByCode(String code) async {
    final s = await db.child('codes/$code').get();
    return s.value as String?;
  }

  static Future<void> sendRequest(String toUid, String fromName, String fromCode) =>
    db.child('users/$toUid/requests').push().set({
      'fromUid': uid, 'fromName': fromName,
      'fromCode': fromCode, 'time': ServerValue.timestamp,
    });

  static Future<void> acceptConnect(String partnerUid) async {
    await db.child('users/$uid').update({'partnerUid': partnerUid, 'connected': true});
    await db.child('users/$partnerUid').update({'partnerUid': uid, 'connected': true});
  }

  static Stream<DatabaseEvent> requestsStream() =>
    db.child('users/$uid/requests').onChildAdded;

  // ── CHAT ──
  static String chatId(String pUid) => ([uid!, pUid]..sort()).join('_');

  static Future<void> sendMsg(String pUid, String text, String name) =>
    db.child('chats/${chatId(pUid)}').push().set({
      'uid': uid, 'name': name, 'text': text, 'time': ServerValue.timestamp,
    });

  static Stream<DatabaseEvent> chatStream(String pUid) =>
    db.child('chats/${chatId(pUid)}').orderByChild('time').onChildAdded;

  // ── DRAW ──
  static Future<void> sendStroke(String pUid, Map stroke) =>
    db.child('draws/${chatId(pUid)}/strokes').push().set({...stroke, 'uid': uid});

  static Stream<DatabaseEvent> drawStream(String pUid) =>
    db.child('draws/${chatId(pUid)}/strokes').onChildAdded;

  // Lock screen image — screenshot of drawing sent to partner
  static Future<void> sendDrawImage(String pUid, String b64, String name) =>
    db.child('draws/${chatId(pUid)}/latest').set({
      'image': b64, 'from': name, 'time': ServerValue.timestamp,
    });

  static Stream<DatabaseEvent> drawImageStream(String pUid) =>
    db.child('draws/${chatId(pUid)}/latest').onValue;

  // ── CLEAR ──
  static Future<void> clearDraw(String pUid) =>
    db.child('draws/${chatId(pUid)}/strokes').remove();
}
