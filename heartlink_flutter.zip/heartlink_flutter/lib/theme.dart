import 'package:flutter/material.dart';

class C {
  static const rose = Color(0xFFF0607A);
  static const deep = Color(0xFF0C0610);
  static const gold = Color(0xFFE8C07A);
  static const muted = Color(0xFF7A6080);
  static const card = Color(0x0DFFFFFF);
  static const border = Color(0x33F0607A);
  static const green = Color(0xFF4ADE80);
  static const purple = Color(0xFFA78BFA);
  static const bg2 = Color(0xFF130920);

  static const grad = LinearGradient(
    colors: [rose, Color(0xFFC23B55)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static BoxDecoration cardBox({double radius = 18}) => BoxDecoration(
    color: card,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: border),
  );

  static BoxDecoration gradBox({double radius = 50}) => BoxDecoration(
    gradient: grad,
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [BoxShadow(color: rose.withOpacity(0.35), blurRadius: 20, offset: const Offset(0,6))],
  );
}

// Reusable gradient button
class GradBtn extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final double height;
  const GradBtn(this.label, {super.key, this.onTap, this.height = 52});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 100),
      width: double.infinity, height: height,
      decoration: C.gradBox(),
      child: Center(child: Text(label,
        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500))),
    ),
  );
}

// Dark text field
class DarkField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final TextInputType type;
  final bool center, caps, obscure;
  final int? maxLength;
  final Function(String)? onChange;
  const DarkField(this.ctrl, this.hint, {super.key,
    this.type = TextInputType.text, this.center = false,
    this.caps = false, this.obscure = false,
    this.maxLength, this.onChange});

  @override
  Widget build(BuildContext context) => TextField(
    controller: ctrl, keyboardType: type, obscureText: obscure,
    textAlign: center ? TextAlign.center : TextAlign.start,
    maxLength: maxLength, onChanged: onChange,
    textCapitalization: caps ? TextCapitalization.characters : TextCapitalization.none,
    style: TextStyle(color: Colors.white, fontSize: center ? 20 : 15,
      letterSpacing: center ? 6 : 0),
    decoration: InputDecoration(
      hintText: hint, hintStyle: const TextStyle(color: C.muted),
      counterText: '',
      filled: true, fillColor: Colors.white.withOpacity(0.06),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.rose, width: 1.5)),
    ),
  );
}
