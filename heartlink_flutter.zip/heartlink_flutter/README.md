# 💕 HeartLink Flutter App — APK Build Guide

## ⭐ LOCK SCREEN FEATURE kaise kaam karta hai
Jab Partner draw karta hai:
1. Drawing Firebase mein save hoti hai
2. Partner ke phone par full-screen notification aati hai
3. Notification lock screen par bhi dikhti hai drawing ke sath
4. Bilkul Lovora jaisi!

---

## 🔥 Step 1: Firebase Setup (5 min)

1. **firebase.google.com** → Get Started
2. New Project banao → name: `heartlink`
3. **Authentication** → Sign-in method → **Phone** ENABLE karo
4. **Realtime Database** → Create → **Test mode**
5. **Project Settings** → Add Web App → Config copy karo
6. **`lib/main.dart`** mein apna config paste karo:
```dart
options: const FirebaseOptions(
  apiKey: "APNA_API_KEY_YAHAN",
  appId: "APNA_APP_ID",
  messagingSenderId: "SENDER_ID",
  projectId: "PROJECT_ID",
  databaseURL: "https://PROJECT_ID-default-rtdb.firebaseio.com",
),
```

7. Firebase Console → Project Settings → **google-services.json** download karo
8. Is file ko **`android/app/google-services.json`** mein rakho

---

## 📦 Step 2: Codemagic par FREE APK build

### Codemagic.io (500 free minutes/month)

1. **codemagic.io** par jaao → Sign up with GitHub
2. GitHub par new repository banao → `heartlink-app`
3. Is ZIP ke saare files upload karo repository mein
4. Codemagic mein → **Add application** → GitHub repo select karo
5. **Flutter App** select karo
6. Build karo!

### Ya FlutLab.io par try karo
1. **flutlab.io** → New Project → Flutter
2. Files paste karo
3. Build → APK download

---

## 📱 Step 3: Phone par install

1. APK download karo
2. Phone mein **Settings → Install unknown apps** allow karo
3. APK install karo
4. Done! 🎉

---

## 🎨 Features in this app

- ✅ Real phone OTP login
- ✅ Partner connect via code
- ✅ Live drawing — Firebase real-time sync
- ✅ **Drawing → Lock screen notification** (full-screen!)
- ✅ Chat + 5-min credit timer
- ✅ Ads system (12hr cooldown)
- ✅ Credits system
- ✅ Profile + stats
- ✅ Admin panel (triple-tap logo → admin123)

---

## ⚠️ Important Notes

- **google-services.json** apna khud daalna hai (Firebase se download)
- `lib/main.dart` mein Firebase config replace karna hai
- Phone OTP ke liye Firebase Authentication mein phone number add karo (test numbers)
- First build mein 10-15 min lagenge

---

## 🆘 Help chahiye?

Codemagic build error aaye to screenshot lo aur Claude ko dikhao — fix kar denge! 💪
